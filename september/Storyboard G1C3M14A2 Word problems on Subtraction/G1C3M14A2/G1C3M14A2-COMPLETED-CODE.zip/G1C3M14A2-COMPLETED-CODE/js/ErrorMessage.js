const ErrorMessage = ({ result, flag }) => {
  return /*#__PURE__*/ React.createElement(
    "div",
    null,
    flag === 1 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 7
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("PencilErrors.totalSuccess")
            )
          : result > 7
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("PencilErrors.largeNumber")
            )
          : result === null
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("PencilErrors.emptyError")
            )
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("PencilErrors.smallerNumber")
            )
      ),
    flag === 2 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 4
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("pencilTakenAwayError.success")
            )
          : result > 4
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("pencilTakenAwayError.largerError")
            )
          : result === null
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("pencilTakenAwayError.emptyError")
            )
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("pencilTakenAwayError.smallerError")
            )
      ),
    flag === 3 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 3
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("pencilSentanceError.success")
            )
          : result > 3
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("pencilSentanceError.largerError")
            )
          : result === null
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("pencilSentanceError.emptyError")
            )
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("pencilSentanceError.smallerError")
            )
      ),
    flag === 4 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 9
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleLargerError.success")
            )
          : result > 9
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleLargerError.smallerError")
            )
          : result === null
          ? /*#__PURE__*/ React.createElement("p", null, t(""))
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleLargerError.smallerError")
            )
      ),
    flag === 5 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 7
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleSmallerError.success")
            )
          : result > 7
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleSmallerError.largerError")
            )
          : result === null
          ? /*#__PURE__*/ React.createElement("p", null, t(""))
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleSmallerError.smallerError")
            )
      ),
    flag === 6 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 2
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleSenetanceError.success")
            )
          : result > 2
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleSenetanceError.largerNumber")
            )
          : result === null
          ? /*#__PURE__*/ React.createElement("p", null, t(""))
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("marbleSenetanceError.smallerError")
            )
      ),
    flag === 7 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 6
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoeTotal.success")
            )
          : result === 2
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoeTotal.partError")
            )
          : result > 6
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoeTotal.largerError")
            )
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoeTotal.smallerError")
            )
      ),
    flag === 8 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 2
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoesRipe.success")
            )
          : result === 6
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoesRipe.partError")
            )
          : result > 2
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoesRipe.largerError")
            )
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoesRipe.smallerError")
            )
      ),
    flag === 9 &&
      /*#__PURE__*/ React.createElement(
        "div",
        null,
        result === 4
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoSentanceError.success")
            )
          : result > 4
          ? /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoSentanceError.largerError")
            )
          : /*#__PURE__*/ React.createElement(
              "p",
              null,
              t("mangoSentanceError.smallerError")
            )
      )
  );
};
window.ErrorMessage = ErrorMessage;
