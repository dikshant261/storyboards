const Fraction = ({
  numerator,
  denominator,
  fontSize = "2vw",
  color = "white",
  lineWidth = "3vw",
  lineHeight = "0.2vh"
}) => {
  return /*#__PURE__*/React.createElement("div", {
    className: "question-fraction",
    style: {
      fontSize,
      color
    }
  }, /*#__PURE__*/React.createElement("span", {
    className: "numerator"
  }, numerator), /*#__PURE__*/React.createElement("span", {
    className: "line",
    style: {
      width: lineWidth,
      height: lineHeight,
      backgroundColor: color
    }
  }), /*#__PURE__*/React.createElement("span", {
    className: "denominator"
  }, denominator));
};
window.Fraction=Fraction;