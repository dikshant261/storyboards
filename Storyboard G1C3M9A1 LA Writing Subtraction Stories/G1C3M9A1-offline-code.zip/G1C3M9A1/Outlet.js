const { useState,useEffect } = React;

const Outlet = () => {
  const [pageIndex, setPageIndex] = useState(0);
  const [showPage, setShowPage] = useState(true);
  const [showFrame, setShowFrame] = useState(false);

  const pages = [
    { Page: FirstPage, Frame: FrameOne },
    { Page: SecondPage, Frame: FrameTwo },
    { Page: ThirdPage, Frame: FrameThird },
  ];

  const handlePage = () => {
    setShowPage(false);
    setShowFrame(true);
  };

  const handleFrame = () => {
    setShowFrame(false);
    if (pageIndex === pages.length - 1) {
      window.location.reload();
      return;
    }
    setPageIndex((prev) => prev + 1);
    setShowPage(true);
  };

  const current = pages[pageIndex];

  return React.createElement(
    "div",
    { className: "outlet" },
    showPage &&
      React.createElement(current.Page, {
        onClose: handlePage,
      }),
    showFrame &&
      React.createElement(current.Frame, {
        onNext: handleFrame,
      })
  );
};

window.Outlet = Outlet;
