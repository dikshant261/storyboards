const FirstPage = ({ onClose }) => {
  const imageone='assets/imageone.png'  
  const click="assets/click.mp3"
  const clickAudio = new Audio(click);
  clickAudio.preload = "auto"; // ensures it's loaded early

  const clickHandle = () => {
    clickAudio.currentTime = 0; // reset to start
    clickAudio.play();
  };

  const handleStart = () => {
    clickHandle();
    onClose();
  };

  return React.createElement(
    "div",
    { className: "contianer" },

    // Left container
    React.createElement(
      "div",
      { className: "container-left" },
      React.createElement("p", { className: "slide-right" }, t("thePicture")),
      React.createElement("p", { className: "slide-left" }, t("writeStory"))
    ),

    // Right container
    React.createElement(
      "div",
      { className: "container-right" },

      // Image item container
      React.createElement(
        "div",
        { className: "contianer-img-item" },

        // Image box
        React.createElement(
          "div",
          { className: "image-container" },
          React.createElement("img", {
            src: imageone,
            alt: "image",
            className: "image scale-up",
          })
        ),

        // Number alignment
        React.createElement(
          "div",
          { className: "align-box" },
          React.createElement("div", { className: "image-box slide-right" }, "6"),
          React.createElement("div", { className: "minus-line" }),
          React.createElement("div", { className: "image-box slide-mid" }, "2"),

          React.createElement(
            "div",
            { style: { display: "flex", flexDirection: "column", gap: "0.5vw" } },
            React.createElement("div", { className: "minus-line" }),
            React.createElement("div", { className: "minus-line" })
          ),

          React.createElement("div", { className: "image-box slide-right" }, "4")
        )
      ),

      // Button section
      React.createElement(
        "div",
        { className: "container-left-option" },
        React.createElement(
          "div",
          { className: "slide-mid" },
          React.createElement(
            "button",
            {
              className: "start-button",
              onClick: handleStart,
            },
            t("start")
          )
        )
      ),

      // Footer section
      React.createElement(
        "div",
        { className: "container-left-navigation" },
        React.createElement(
          "h3",
          { className: "footer-heading" },
          React.createElement("h2", { className: "slide-left" }, t("tapStart"))
        )
      )
    )
  );
};

window.FirstPage = FirstPage;
