const FrameOne = ({ onNext }) => {
  const [sideHeadingOne, setSideHeadingOne] = React.useState(true);
  const [stepOne, setStepOne] = React.useState(false);
  const [stepTwo, setStepTwo] = React.useState(false);
  const [stepThree, setStepThree] = React.useState(false);
  const [stepFour, setStepFour] = React.useState(false);
  const [stepFive, setStepFive] = React.useState(false);
  const [arrowAnimation, setArrowAnimation] = React.useState(false);
  const imageone = "assets/imageone.png";
  const click = "assets/click.mp3";
  const wrong = "assets/wrong.mp3";
  const right = "assets/correct.mp3";

  React.useEffect(() => {
    const timer = setTimeout(() => {
      setArrowAnimation(true);
    }, 2000);
    return () => clearTimeout(timer);
  }, []);

  // audio variables
  const clickAudio = new Audio(click);
  clickAudio.preload = "auto";

  const clickWrong = new Audio(wrong);
  clickWrong.preload = "auto";

  const clickRight = new Audio(right);
  clickRight.preload = "auto";

  const clickHandle = () => {
    clickAudio.currentTime = 0;
    clickAudio.play();
  };

  const wrongHandle = () => {
    clickWrong.currentTime = 0;
    clickWrong.play();
  };

  const rightHandle = () => {
    clickRight.currentTime = 0;
    clickRight.play();
  };

  const handleStepOne = () => {
    clickHandle();
    setSideHeadingOne(false);
    setStepOne(true);
  };

  const handleOptionOne = (num) => {
    if (num === 1) {
      rightHandle();
      setStepOne(false);
      setStepTwo(true);
    } else {
      wrongHandle();
    }
  };

  const handleOptionTwo = (num) => {
    if (num === 2) {
      rightHandle();
      setStepTwo(false);
      setStepThree(true);
    } else {
      wrongHandle();
    }
  };

  const handleOptionThree = (num) => {
    if (num === 1) {
      rightHandle();
      setStepThree(false);
      setStepFour(true);
    } else {
      wrongHandle();
    }
  };

  const handleStory = () => {
    clickHandle();
    setStepFour(false);
    setStepFive(true);
  };

  const handleNext = () => {
    clickHandle();
    setStepFive(false);
    setArrowAnimation(false);
    onNext();
  };

  return React.createElement(
    "div",
    { className: "frame-contianer" },

    // LEFT SIDE
    React.createElement(
      "div",
      { className: "frame-container-left" },
      sideHeadingOne &&
        React.createElement(
          "p",
          { className: "slide-left" },
          t("sideHeadingOne")
        ),
      stepOne &&
        React.createElement(
          "div",
          { className: "slide-right" },
          React.createElement(
            "p",
            {
              style: {
                fontWeight: 900,
                textAlign: "left",
                marginBottom: "1vw",
              },
            },
            t("stepOne")
          ),
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("chooseOption")
          )
        ),
      stepTwo &&
        React.createElement(
          "div",
          { className: "slide-mid" },
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("stepOne"),
            " ✅"
          ),
          React.createElement(
            "p",
            { style: { fontWeight: 900, textAlign: "left" } },
            t("stepTwo")
          ),
          React.createElement(
            "p",
            { style: { marginTop: "3vw", textAlign: "left" } },
            t("chooseOption")
          )
        ),
      stepThree &&
        React.createElement(
          "div",
          { className: "slide-left" },
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("stepOne"),
            " ✅"
          ),
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("stepTwo"),
            " ✅"
          ),
          React.createElement(
            "p",
            { style: { fontWeight: "900", textAlign: "left" } },
            t("stepThree")
          ),
          React.createElement(
            "p",
            { style: { marginTop: "2vw", textAlign: "left" } },
            t("chooseOption")
          )
        ),
      stepFour &&
        React.createElement(
          "div",
          { className: "slide-right" },
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("stepOne"),
            " ✅"
          ),
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("stepTwo"),
            " ✅"
          ),
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            React.createElement("b", null, t("stepThree"), " ✅")
          ),
          React.createElement(
            "p",
            { style: { marginTop: "2vw", textAlign: "left" } },
            t("allStep")
          )
        ),
      stepFive &&
        React.createElement(
          "div",
          { className: "slide-mid" },
          React.createElement(
            "p",
            {
              style: {
                fontWeight: 800,
                textAlign: "left",
                marginBottom: "2vw",
              },
            },
            t("makeNote")
          ),
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("rememberStep")
          ),
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("stepOne"),
            " ✅"
          ),
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("stepTwo"),
            "✅"
          ),
          React.createElement(
            "p",
            { style: { textAlign: "left" } },
            t("stepThree"),
            "✅"
          )
        )
    ),

    // RIGHT SIDE
    React.createElement(
      "div",
      { className: "frame-container-right" },
      React.createElement(
        "div",
        { className: "frame-contianer-img-item" },
        stepFive &&
          React.createElement(
            "div",
            { className: "story scale-up" },
            React.createElement("p", null, t("storyOneText"))
          ),

        React.createElement(
          "div",
          { className: "frame-image-container" },
          React.createElement("img", {
            src: imageone,
            alt: "image",
            className: "frame-image scale-up",
          })
        ),

        React.createElement(
          "div",
          { className: "frame-align-box", style: { position: "relative" } },
          React.createElement(
            "div",
            {
              className: `${
                stepOne ? "box-size" : ""
              } frame-image-box slide-left`,
            },
            "6"
          ),
          React.createElement("div", { className: "frame-minus-line" }),
          React.createElement(
            "div",
            {
              className: `${
                stepTwo ? "box-size" : ""
              } frame-image-box slide-right`,
            },
            "2"
          ),
          React.createElement(
            "div",
            {
              style: { display: "flex", flexDirection: "column", gap: "0.5vw" },
            },
            React.createElement("div", {
              className: "frame-minus-line slide-up",
            }),
            React.createElement("div", {
              className: "frame-minus-line slide-right",
            })
          ),
          React.createElement(
            "div",
            {
              className: `${
                stepThree ? "box-size" : ""
              } frame-image-box slide-left`,
            },
            "4"
          ),

          sideHeadingOne &&
            arrowAnimation &&
            React.createElement(
              "div",
              null,
              React.createElement(
                "div",
                { className: `${arrowAnimation ? "show-in" : ""}` },
                React.createElement(
                  "svg",
                  {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "10.9 8.9 1.2 1.2",
                    className: "arrow-align-one",
                  },
                  React.createElement("path", {
                    d: "M 12 9 Q 11 9 11 10",
                    stroke: "gold",
                    "stroke-width": "0.06",
                    fill: "none",
                  })
                )
              ),
              React.createElement(
                "div",
                { className: `${arrowAnimation ? "show-in" : ""}` },
                React.createElement(
                  "svg",
                  {
                    xmlns: "http://www.w3.org/2000/svg",
                    viewBox: "10.9 8.9 1.2 1.2",
                    className: "arrow-align-two",
                  },
                  React.createElement("path", {
                    d: "M 12 9 Q 11 9 11 10",
                    stroke: "gold",
                    "stroke-width": "0.06",
                    fill: "none",
                  })
                )
              ),
              React.createElement(
                "div",
                null,
                React.createElement("div", { className: "arrow-line show-in" })
              ),
              React.createElement(
                "div",
                { style: { whiteSpace: "pre-line" } },
                React.createElement(
                  "p",
                  { className: "total-number show-in" },
                  t("totalNumber")
                ),
                React.createElement(
                  "p",
                  { className: "take-away show-in" },
                  t("takenAway")
                ),
                React.createElement(
                  "p",
                  { className: "ramains show-in" },
                  t("remain")
                )
              )
            )
        )
      ),

      // OPTIONS SECTION
      React.createElement(
        "div",
        { className: "frame-container-left-option" },
        stepOne &&
          React.createElement(
            "div",
            { className: "option-align" },
            React.createElement(
              "div",
              { className: "option-align-col slide-right" },
              React.createElement(Option, {
                content: t("storyOne.optionOne"),
                onClick: () => handleOptionOne(1),
              }),
              React.createElement(Option, {
                content: t("storyOne.optionTwo"),
                onClick: () => handleOptionOne(2),
              })
            ),
            React.createElement(
              "div",
              { className: "option-align-col slide-left" },
              React.createElement(Option, {
                content: t("storyOne.optionThree"),
                onClick: () => handleOptionOne(3),
              }),
              React.createElement(Option, {
                content: t("storyOne.optionFour"),
                onClick: () => handleOptionOne(4),
              })
            )
          ),
        stepTwo &&
          React.createElement(
            "div",
            { className: "option-align" },
            React.createElement(
              "div",
              { className: "option-align-col slide-right" },
              React.createElement(Option, {
                content: t("storyOne.optionFive"),
                onClick: () => handleOptionTwo(1),
              }),
              React.createElement(Option, {
                content: t("storyOne.optionSix"),
                onClick: () => handleOptionTwo(2),
              })
            ),
            React.createElement(
              "div",
              { className: "option-align-col slide-left" },
              React.createElement(Option, {
                content: t("storyOne.optionSeven"),
                onClick: () => handleOptionTwo(3),
              }),
              React.createElement(Option, {
                content: t("storyOne.optionEight"),
                onClick: () => handleOptionTwo(4),
              })
            )
          ),
        stepThree &&
          React.createElement(
            "div",
            { className: "option-align" },
            React.createElement(
              "div",
              { className: "option-align-col slide-left" },
              React.createElement(Option, {
                content: t("storyOne.optionNine"),
                onClick: () => handleOptionThree(1),
              }),
              React.createElement(Option, {
                content: t("storyOne.optionTen"),
                onClick: () => handleOptionThree(2),
              })
            ),
            React.createElement(
              "div",
              { className: "option-align-col slide-right" },
              React.createElement(Option, {
                content: t("storyOne.optionEleven"),
                onClick: () => handleOptionThree(3),
              }),
              React.createElement(Option, {
                content: t("storyOne.optionTweleve"),
                onClick: () => handleOptionThree(4),
              })
            )
          ),
        stepFour &&
          React.createElement(
            "div",
            { className: "slide-mid" },
            React.createElement(
              "button",
              {
                className: "frame-start-button",
                style: {
                  width: "18vw",
                  display: "flex",
                  justifyContent: "center",
                  alignItems: "center",
                  height: "8vh",
                  fontWeight: "900",
                },
                onClick: handleStory,
              },
              t("makeStory")
            )
          )
      ),

      // FOOTER
      React.createElement(
        "div",
        {
          className: "frame-container-left-navigation",
          style: { position: "relative" },
        },
        sideHeadingOne &&
          React.createElement(
            "h2",
            { className: "frame-footer-heading slide-right" },
            t("tapContinue")
          ),
        stepOne &&
          React.createElement(
            "h2",
            { className: "frame-footer-heading slide-right" },
            t("tapCorrect")
          ),
        stepTwo &&
          React.createElement(
            "h2",
            { className: "frame-footer-heading slide-right" },
            t("tapCorrect")
          ),
        stepThree &&
          React.createElement(
            "h2",
            { className: "frame-footer-heading slide-right" },
            t("tapCorrect")
          ),
        stepFour &&
          React.createElement(
            "h2",
            { className: "frame-footer-heading slide-right" },
            t("tapStory")
          ),
        stepFive &&
          React.createElement(
            "h2",
            { className: "frame-footer-heading slide-left" },
            t("tapNextQuestion")
          ),

        React.createElement(
          "div",
          null,
          sideHeadingOne &&
            React.createElement(
              "button",
              { className: "next-button slide-mid", onClick: handleStepOne },
              "▶"
            ),
          stepFive &&
            React.createElement(
              "button",
              { className: "next-button slide-mid", onClick: handleNext },
              "▶"
            )
        )
      )
    )
  );
};
window.FrameOne = FrameOne;
