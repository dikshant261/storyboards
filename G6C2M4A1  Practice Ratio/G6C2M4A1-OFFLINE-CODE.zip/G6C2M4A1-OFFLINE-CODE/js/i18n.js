// content in english
const appData = {
  en: {
    translation: {
      writingRatio: "Representing and Writing Ratios",
      get_ready_to_explore:
        "Get ready to explore ratios in action.\nYou will practice representing ratios in different forms.",
      practiceStart:
        "You have practiced representing ratios \nusing symbol, words, and fractions.",
      getReady: "Now, get ready to practice identifying and\nwriting ratios.",
      nextContinue: "Tap ‘Next’ to continue.",
      start: "START",
      next: "NEXT",
      representingRatios:
        "Represent the ratio of cats to dogs in this picture.",
      tapRatio:
        "Tap the correct ratio in the correct form to fill the highlighted box…",
      great: "Great!",
      repreSenting_ratios: "Represent the ratio as required.",
      dogErrorone: "Oops! We need the {{word}}.\n Try again!",
      dogErrortwo: "Not quite! We need cats first, then dogs.\n Try again!",
      dogErrorFraction: "Not quite! We need cats at numerator. Try again!",
      success: "is the the correct {{word}} form required!",
      successTwo: "Great! {{count}} is the correct ratio required.",
      successThree: "is the correct ratio required.",
      proceed: "Tap ▶ to proceed.",
      tapNext: "Tap ▶ to next...",
      word: "Word",
      fraction: "Fraction",
      symbol: "Symbol",
      questionOne:
        "At a table for 8,\n 6 seats are filled\n and 2 seats are empty.",
      questionTwo:
        "At a table for 8, \n2 seats are empty and 6 seats are filled.",
      questionThree: "A bag contains 9 yellow marbles and 7 blue marbles.",
      questionFive: "A classroom has 9 boys and 14 girls.",
      questionSix: "A basket contains 16 apples and 19 bananas.",
      questionSeven:
        "32 students in the classroom and 25 students in the playground.",
      questionThreeHeading: "Represent the ratio of yellow to blue marbles.",
      questionFour: "A bag contains 9 yellow marbles and 7 blue marbles.",
      questionFourHeading: "Represent the ratio of blue to yellow marbles.",
      emptyChairsHeading: "Represent the ratio of filled to empty seats.",
      tableErrorSymbol:
        "Not quite! We need filled seats first, then empty seats. Try again!",
      tableErrorFraction:
        "Not quite! We need filled seats at numerator. Try again!",
      yellowMarble:
        "Not quite! We need yellow marbles first, then blue marbles. Try again!",
      yellowMarbleFraction:
        "Not quite! We need yellow marbles at numerator. Try again!",
      blueMarbles:
        "Not quite! We need blue marbles first, then yellow marbles. Try again!",
      blueMarblesFraction:
        "Not quite! We need blue marbles at numerator. Try again!",

      //new part

      ratioApple: "Ratio of \napples to oranges",
      rationOrange: "Ratio of \noranges to apples",
      ratioBoys: "Ratio of \nboys to girls",
      ratioGirl: "Ratio of \ngirls to boys",
      rationBanana: "Ratio of\nbananas to apples",
      ratioOrange: "Ratio of\nbananas to apples",
      ratioStudent: "Ratio of students in\nplayground to classroom",
      ratioPlaground: "Ratio of students in\nclassroom to playground",
      ratio_of_pentagons: "Ratio of triangles to pentagons",
      ratio_of_triangles: "Ratio of pentagons to triangles",
      appleErrorOne:
        "Oops! That’s not correct. There are 5 oranges, not 10. Try again!",
      appleErrorTwo:
        "Not quite! We need apples first, then oranges. \nTry again!",
      orangeErrorOne:
        "Oops! That’s not correct. There are 4 apples, not 10. \nTry again!",
      orangeErrorTwo:
        "Not quite! We need oranges first, then apples. \nTry again!",
      triangleErrorOne:
        "Not quite! We need pentagons first, then triangles. \nTry again!",
      triangleErrorTwo:
        "Oops! That’s not correct. There are 7 triangles, not 10. \nTry again!",
      pentagonErrorOne:
        "Not quite! We need triangles first, then pentagons. \nTry again!",
      pentagonErrorTwo:
        "Oops! That’s not correct. There are 3 pentagons, not 10. \nTry again!",
      boyFirstErrorOne:
        "Not quite! We need boys first, then girls. \nTry again!",
      boyFirstErrorTwo:
        "Oops! That’s not correct. There are 14 girls, not 23. \nTry again!",
      girlsFirstErrorOne:
        "Not quite! We need boys first, then girls. \nTry again!",
      girlsFirstErrorTwo:
        "Oops! That’s not correct. There are 9 boys, not 23. \nTry again!",
      bananaFirstErrorOne:
        "Not quite! We need bananas first, then apples. \nTry again!",
      bananaFirstErrorTwo:
        "Oops! That’s not correct. There are 16 apples, not 35. \nTry again!",
      appleFirstErrorOne:
        "Not quite! We need apples first, then bananas. \nTry again!",
      appleFirstErrorTwo:
        "Oops! That’s not correct. There are 19 bananas, not 35. \nTry again!",
      studentErrorOne:
        "Not quite! We need students in playground first. \nTry again!",
      studentErrorTwo:
        "Oops! That’s not correct. There are 32 students in classroom, not 57. \nTry again!",
      studentPalygroundOne:
        "Not quite! We need students in classroom first. \nTry again!",
      studentPalygroundTwo:
        "Oops! That’s not correct. There are 25 students in playground, not 57. \nTry again!",

      //complete
      activityComplete: "Activity Completed!",
      leraned_forms:
        "You have learned how to identify and represent ratios \nin symbol, fraction, and word forms.",
      startOver: "To go over the activity again, tap on ‘Start Over’.",
      buttonStartOver: "Start Over",
    },
  },
};

// Current language comes from global APP_LANGUAGE set in index.html
const currentLang = window.APP_LANGUAGE || "en";

// Helper: resolve nested keys like "storyOne.optionOne"
function getNested(obj, path) {
  return path.split(".").reduce((acc, key) => {
    return acc && acc[key] !== undefined ? acc[key] : null;
  }, obj);
}

// Translator function
function t(key, params = {}) {
  let text = getNested(appData[currentLang].translation, key) || key;

  // Replace variables if any (like {{count}})
  Object.keys(params).forEach((p) => {
    text = text.replace(`{{${p}}}`, params[p]);
  });

  return text;
}

// Expose globally so all components can use it
window.t = t;
